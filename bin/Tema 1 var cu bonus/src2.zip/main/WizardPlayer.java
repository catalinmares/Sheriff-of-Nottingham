package main;

import java.util.List;

public class WizardPlayer extends BasicPlayer {

    public WizardPlayer(final List<Goods> inHandGoods) {
        super(inHandGoods);
    }

    public final void createSack() {
        super.createSack();

        if (getSack().get(0).getType().equals("Illegal")) {
            setBribe(1);
        }
    }

    @Override
    public final void control(final BasicPlayer player) {
        // Daca comerciantul a dat mita, se returneaza mita si se verifica sacul
        if (player.getBribe() != 0) {
            player.resetBribe();
            super.control(player);
        } else {
            // Altfel, nu se verifica sacul
            return;
        }
    }

}
