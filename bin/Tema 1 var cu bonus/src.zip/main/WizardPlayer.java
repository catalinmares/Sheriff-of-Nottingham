package main;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WizardPlayer extends BasicPlayer {
    
    public WizardPlayer(final List<Goods> inHandGoods) {
        super(inHandGoods);
    }

    public final void createSack() {
    	while (getSack().size() < 5) {
    		super.createSack();
    	}
    	
    	setBribe(1);
    	
    	if (getSack().size() > 5) {
    		System.out.println("Sacul a depasit dimensiunea maxima");
    		GoodsComparator goodsComparator = new GoodsComparator();
    		Collections.sort(getSack(), goodsComparator);
    		
    		while (getSack().size() > 5) {
    			getSack().remove(0);
    		}
    	}
    	
    	Map<Goods, Integer> countFrequency = new HashMap<Goods, Integer>();
        int[] frequency = new int[Main.MAXID];

        for (Goods asset : getSack()) {
            countFrequency.put(asset, countFrequency.getOrDefault(asset, 0) + 1);
        }

        // Determinare frecvente pentru fiecare bun din mana jucatorului
        for (Goods asset : countFrequency.keySet()) {
            frequency[asset.getId()] += countFrequency.get(asset);
        }

        int maxFrequency = Main.maxValue(frequency, Main.NRLEGALGOODS);
        Goods declaration = null;

        // Determinarea profitului bunurilor cu frecventa maxima
        for (Goods asset : getSack()) {
        	if (frequency[asset.getId()] == maxFrequency && asset.getType().equals("Legal")) {
        		declaration = asset;
        		break;
        	}
        }
        
        setDeclaration(declaration.getName());
    	
    	System.out.println("Afisam sacul");
    	for (Goods asset : getSack()) {
    		System.out.println(asset.getName());
    	}
    	
    	System.out.println("Am declarat " + declaration.getName());
    }

    @Override
    public final void control(final BasicPlayer player) {
        // Daca comerciantul a dat mita, se returneaza mita si se verifica sacul
        if (player.getBribe() != 0) {
            player.resetBribe();
            super.control(player);
        } else {
            // Altfel, nu se verifica sacul
            return;
        }
    }

}
